package emailapp;

import java.util.Scanner;

public class Email {

		private String firstName;
		private String lastName;
		private String password;
		private String department;
		private int mailBoxCapacity = 500;
		private int defaultpasswordLength = 10;
		private String email;
		private String alternateEmail;
		private String emailSuffix = "company.com";
		
		
		//contructor to receive the first name and last name
		public Email(String firstName , String lastName) {
			this.firstName = firstName;
			this.lastName = lastName;
			System.out.println("Email Created : "+ this.firstName + " " + this.lastName);
				
			
			//call a method asking for department & return the department
			department = setDepartment();
			System.out.println("Department is : " + department);
			
			//method that return a random password
			this.password = randomPassword(defaultpasswordLength);
			System.out.println("Your Password is :"+ this.password);
			
			//combine elements to generate email
			
			email = firstName.toLowerCase() + "." +lastName.toLowerCase() + "@" + department + "." + emailSuffix;
			//System.out.println("Your email is : " + email);
		}
		//Ask for department
		
		private String setDepartment() {
			System.out.println("Department Codes\n1. for Sales\n2. for Development\n3. for Accounting ");
			Scanner in = new Scanner(System.in);
			int deptChoice = in.nextInt();
			
			if(deptChoice == 1) { return "sales";}
			else if(deptChoice == 2) { return "Development";}
			else if(deptChoice == 3) { return "Accounting";}
			else return "No Choice";
			
			/*switch(deptChoice) {
			case 1:
				return "sales";
			case 2:
				return "Development";
			case 3:
				return "Accounting";	
			default:
				return "";
			
			}*/
			
			
		}
		
		//Generate a Password
		private String randomPassword(int length) {
			String passwordSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%";
			char[] password = new char[length];//to iterate length one by one
			for(int i=0;i<length;i++) {
				int rand = (int) (Math.random() * passwordSet.length()); //(math.random will give 0 and 1) *(multiplied by length)
				password[i] = passwordSet.charAt(rand);//we are picking random character and setting it to current position of i
			}
			return new String(password);//password will be set of character so we are changing it to string
		}
		
		
		//set the mailbox capacity
		public void setMailBoxCapacity(int capacity) {
			this.mailBoxCapacity = capacity;
		}
		
		//set the alternate email
		public void setAlternateEmail(String altEmail) {
			this.alternateEmail = altEmail;
		}
		
		//chnage the password
		public void changePassword(String password) {
			this.password = password;
		}
		
		public int getMailBoxCapacity() {return mailBoxCapacity;}
		public String getAlternateEmail() {return alternateEmail;}
		public String getPassword() {return password;}
		
		public String showInfo() {
			return "Display name : " + firstName +" " + lastName +   "\nComapny Email : " + email + " \nMailBox Capacity : " +  mailBoxCapacity  ;
		}
}
