package emailapp;

public class EmailApp {

	public static void main(String[] args) {
		
		Email em1 = new Email("Shashank","Landole");
		
		/*em1.setAlternateEmail("slandole82@gmail.com");
		System.out.println(em1.getAlternateEmail());
		
		em1.changePassword("ss");
		System.out.println(em1.getPassword());*/
		
		System.out.println(em1.showInfo());

	}

}
